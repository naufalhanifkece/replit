import os

if __name__ == "__main__":
  os.system("python manage.py runserver 0.0.0.0:8000")
